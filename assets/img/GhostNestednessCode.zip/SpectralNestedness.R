#############################################
#############################################
## R code accompanying
## ``The ghost of nestedness in ecological networks''
## by Phillip P.A. Staniczenko, Jason C. Kopp and Stefano Allesina
## Nature Communications 4:1391 doi: 10.1038/ncomms2422 (2013)
#############################################
#############################################
## If you source("SpectralNestedness.R")
##
## Tests for nestedness for a binary or quantitative incidence (bipartite) matrix A,
## tests return:
## i) Success  1 if test completes successfully, 0 otherwise
## ii) Eigen  dominant eigenvalue of the empirical provided matrix
## iii) EigenRand  vector of dominant eigenvalues of randomized matrices
## iv) Probability  p-value for nestedness, p < 0.05 means graph is significantly nested
##                                          p > 0.95 mean graph is significantly anti-nested
## v) Test  which test was run           
##
##
## TestNestednessEigen1(A, HowMany)
## where HowMany is the number of ER random graphs to test against
## (shuffle matrix coefficients)
##
## TestNestednessEigen2(A, HowMany, HowManyToTry)
## where HowMany is the number of connected ER random graphs to test against
## (shuffle matrix coefficients and ensure graph is connected)
## and HowManyToTry is the total number of randomisations to try to find connected graphs
##
## TestNestednessEigen3(A, HowMany, HowManyToTry)
## where HowMany is the number of graphs with the same degree distribution as A to test against
## and HowManyToTry is the number of trial swaps to attempt for each test graph
##
## TestNestednessEigen4(A, HowMany)
## where HowMany is the number of randomisations to test against
## (shuffle non-zero matrix coefficients, binary structure is maintained)
##
##
## Other functions
##
## Find perfectly nested binary matrix with minimum spectral radius:
## BuildNestedWithMinEigen(NumP=7, NumA=6, Links=23)
##
## Extract giant connected component from incidence matrix A:
## ExtractGiantComponent(A)


#############################################
## Calculate spectral radius
#############################################
## Takes a (possibly rectangular) incidence 
## matrix A where A_ij > 0 means that species i (row)
## interacts with species j (column) and return
## the dominant eigenvalue of the corresponding
## adjacency matrix
DominantEigenFromIncidence <- function(A){
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  S <- NumP + NumA
  Adj <- matrix(0, S, S)
  Adj[1:NumP, (NumP + 1):S] <- A
  Adj <- Adj + t(Adj)
  return(Re(eigen(Adj)$value[1]))
}

#############################################
## Code Needed to build nested binary matrix with
## Smallest possible dominant eigenvalue
#############################################

## Add one link to A such that the increment
## in the dominant eigenvalue is the smallest
## possible
AddOneLinkToNestedMinEigen <- function(A){
  CSums <- colSums(A) ## these are column sums
  Stop <- which.min(CSums)[1] ## decide where to stop
  ## For example, take a matrix with col sums
  ## 7 5 5 3 2 1 1 1
  ## The possibilities for adding a link are
  ## 7 6 5 3 2 1 1 1
  ## 7 5 5 4 2 1 1 1
  ## 7 6 5 3 3 1 1 1
  ## 7 6 5 3 2 2 1 1
  ## note that of the original 1 1 1 we can only
  ## modify the first (hence the which.min above)
  FoundEigen <- 10000000000.0
  FoundMat <- NULL
  for (i in 2:Stop){
    ## if adding a link keeps the matrix nested
    if (CSums[i] + 1<=CSums[i - 1]){
      ## Try the matrix
      B <- A
      B[CSums[i] + 1, i] <- 1
      ## Compute the eigenvalue
      CurrEigen <- DominantEigenFromIncidence(B)
      ## save the smallest eigenvalue
      if (CurrEigen < FoundEigen){
        FoundEigen <- CurrEigen
        FoundMat <- B
      }
    }
  }
  return(FoundMat)
}

## Builds nested matrix with NumP rows,
## NumA cols and Links links such that
## the matrix is nested and has the smallest
## possible eigenvalue
BuildNestedWithMinEigen <- function(NumP=7, NumA=6, Links=23){
  ## First, build the "L" matrix
  if (Links<(NumP + NumA - 1)){
    print("Error: the matrix has too few connections to be nested!!")
  }
  A <- matrix(0, NumP, NumA)
  A[1, ] <- 1
  A[, 1] <- 1
  InitialLinks <- sum(A)
  ## Now add the remaining links one at a time
  for (i in 1:(Links - InitialLinks)){
    A <- AddOneLinkToNestedMinEigen(A)
  }
  return(list(A=A, Eig=DominantEigenFromIncidence(A)))
}

#############################################
## END Code Needed to build nested binary matrix with
## Smallest possible dominant eigenvalue
#############################################

#############################################
# CHECK CONNECTEDNESS USING
# DEPTH FIRST SEARCH (AFTER TARJAN)
#############################################

## Remove global variables created, specifically ColorsForDFS
CleanEnvir <- function(pattern = "ColorsForDFS"){
      rm(list = ls(envir=globalenv())[
             grep(pattern, ls(envir=globalenv()))], envir = globalenv())
}

DFSForBipartiteGraph <- function(Adj, i, S){
  ColorsForDFS[i] <<- 1 ## assign to a global variable
  for (j in 1:S){
    ## if i->j
    if (Adj[i, j]==1){
      ## if we haven't visited j yet
      if (ColorsForDFS[j]==0){
        DFSForBipartiteGraph(Adj, j, S)
      }
    }
  }
  return(0)
}

IsBipartiteGraphConnected <- function(A){
  ## create a global variable
  assign("ColorsForDFS", NULL, envir=.GlobalEnv)
  ## convert to binary
  A[A > 0] <- 1
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  S <- NumP + NumA
  Adj <- matrix(0, S, S)
  Adj[1:NumP, (NumP+1):S] <- A
  Adj <- Adj + t(Adj)
  ColorsForDFS <<- rep(0, S)
  DFSForBipartiteGraph(Adj, 1, S)
  if (sum(ColorsForDFS)==S){
  	CleanEnvir("ColorsForDFS")
    return(1)
  }
  CleanEnvir("ColorsForDFS")
  return(0)
}

#############################################
# EXTRACT GIANT COMPONENT
#############################################

DFSForGiantComponent <- function(Adj, i, ComponentCounter,S){
  ColorsForDFS[i] <<- ComponentCounter ## assign to a global variable
  for (j in 1:S){
    ## if i->j
    if (Adj[i, j] > 0){
      ## if we haven't visited j yet
      if (ColorsForDFS[j]==0){
        DFSForGiantComponent(Adj, j, ComponentCounter, S)
      }
    }
  }
  return(0)
}

ExtractGiantComponent <- function(A){
  ## create a global variable
  assign("ColorsForDFS", NULL, envir=.GlobalEnv)
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  S <- NumP + NumA
  Adj <- matrix(0, S, S)
  Adj[1:NumP, (NumP + 1):S] <- A
  Adj <- Adj + t(Adj)
  ColorsForDFS <<- rep(0,S)
  ComponentCounter <- 0
  while (sum(ColorsForDFS==0) > 0){
  	ComponentCounter <- ComponentCounter + 1
  	## pick next non-visited node not part of previous component
  	DFSForGiantComponent(Adj, which(ColorsForDFS==0)[1], ComponentCounter, S)
  }
  ## extract giant component
  u <- unique(ColorsForDFS)
  frequencies <- tapply(rep(0, length(ColorsForDFS)), ColorsForDFS, length)
  ComponentId <- u[which.max(frequencies)] ## component with most nodes
  PlantsComponent <- (ColorsForDFS[1:NumP]==ComponentId) * 1:NumP
  AnimalsComponent <- (ColorsForDFS[(NumP + 1):S]==ComponentId) * 1:NumA
  GiantComponent <- A[PlantsComponent, AnimalsComponent]
  if (sum(ColorsForDFS==0)==0){
  	CleanEnvir("ColorsForDFS")
    return(GiantComponent)
  }
  CleanEnvir("ColorsForDFS")
  return(0)
}


#############################################
# TEST FOR  NESTEDNESS 1
#############################################
## Try matrices which have the same number
## of links, plants and animals of the original
## but do not check for connectedness
TestNestednessEigen1 <- function(A, HowMany){
  ## Check whether the empirical graph is connected
  Connected <- IsBipartiteGraphConnected(A)
  if (Connected==0){
    print("Warning: graph is not connected.")
    print("Run ExtractGiantComponent() to obtain largest connected graph.")
    return(0)
  }
  ## Dominant eigenvalue of the original matrix
  EigenA <- DominantEigenFromIncidence(A)
  ## Vector to store eigen for randomizations
  EigenRandomizations <- rep(-1.0, HowMany)
  ## How many we tried so far
  Tried <- 0
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  for (Tried in 1:HowMany){
    ## Build a matrix by shuffling the coefficients
    B <- matrix(sample(A), NumP, NumA)
    ## Compute its eigenvalue
    EigenRandomizations[Tried] <- DominantEigenFromIncidence(B)
  }
  ## Probability of finding a matrix with a larger eigenvalue at random
  ProbabilityLargerEigenvalue <- sum(EigenRandomizations >= EigenA) / HowMany
  
  return(list(Success=1,
              A=A, Eigen=EigenA,
              EigenRand=EigenRandomizations,
              Probability=ProbabilityLargerEigenvalue,
              Test="Test 1"))
}

#############################################
# TEST FOR  NESTEDNESS 2
#############################################
## Try matrices which have the same number
## of links, plants and animals of the original
## and are connected
TestNestednessEigen2 <- function(A, HowMany, HowManyToTry=-1){
  if (HowManyToTry==-1){
    HowManyToTry <- HowMany * 100
  }
  ## Check whether the empirical graph is connected
  Connected <- IsBipartiteGraphConnected(A)
  if (Connected==0){
    print("Warning: graph is not connected.")
    print("Run ExtractGiantComponent() to obtain largest connected graph.")
    return(0)
  }
  EigenA <- DominantEigenFromIncidence(A)
  EigenRandomizations <- rep(-1.0, HowMany)
  Tried <- 0
  Found <- 0
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  Success <- 0
  while ((Tried < HowManyToTry) & (Found < HowMany)){
    Tried <- Tried + 1
    Connected <- 0
    B <- matrix(sample(A), NumP, NumA)
    Connected <- IsBipartiteGraphConnected(B)
    ## Check whether the graph is connected
    if (Connected==1){
      Found <- Found + 1
      EigenRandomizations[Found] <- DominantEigenFromIncidence(B)
    }
  }
  ## Probability of finding a matrix with a larger eigenvalue at random
  ProbabilityLargerEigenvalue <- sum(EigenRandomizations[EigenRandomizations > -1.0] >= EigenA) / Found
  if (Found < HowMany){
    Success <- 0
    print("Warning: I could not find enough connected graphs!")
  }
  if (Found==HowMany){
  Success <- 1
  }
  
  return(list(Success=Success,
              A=A, Eigen=EigenA,
              EigenRand=EigenRandomizations,
              Probability=ProbabilityLargerEigenvalue,
              Test="Test 2"))
}

#############################################
# TEST FOR  NESTEDNESS 3
#############################################
## Try matrices which have the same number
## of links, plants and animals of the original
## and maintain the degree distribution
## Uses ``Trial swap'' algorithm: Miklo ́s, I. & Podani, J. 
##   Randomization of presence–absence matrices: Comments and new algorithms.
##   Ecology 85, 86–92 (2004).
TestNestednessEigen3 <- function(A, HowMany, HowManyToTry=-1){
  if (HowManyToTry==-1){
    HowManyToTry <- HowMany * 100
  }
  ## Check whether the empirical graph is connected
  Connected <- IsBipartiteGraphConnected(A)
  if (Connected==0){
    print("Warning: graph is not connected.")
    print("Run ExtractGiantComponent() to obtain largest connected graph.")
    return(0)
  }
  EigenA <- DominantEigenFromIncidence(A)
  EigenRandomizations <- rep(-1.0, HowMany)
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  Tried <- 0
  for (Tried in 1:HowMany){
  	B <- A
  	count1 <- 0
  	while (count1 < HowManyToTry){
      count1 <- count1 + 1
      ## pick two rows and two columns
      row1 <- sample(1:NumP, 1)
      row2 <- sample(1:NumP, 1)
      col1 <- sample(1:NumA, 1)
      col2 <- sample(1:NumA, 1)
      ## check swappable
      if (B[row1, col1] == 0.0 && B[row1, col2] > 0.0 && B[row2, col1] > 0.0 && B[row2, col2] == 0.0){
      	## swap
    	B[row1, col1] <- B[row1, col2]
    	B[row1, col2] <- 0.0
    	B[row2, col2] <- B[row2, col1]
    	B[row2, col1] <- 0.0
      }
      else{
    	if (B[row1, col1] > 0.0 && B[row1, col2] == 0.0 && B[row2, col1] == 0.0 && B[row2, col2] > 0.0){
          ## swap
    	  B[row1, col2] <- B[row1, col1]
    	  B[row1, col1] <- 0.0
    	  B[row2, col1] <- B[row2, col2]
    	  B[row2, col2] <- 0.0
    	  }
      }
    }
  EigenRandomizations[Tried] <- DominantEigenFromIncidence(B)
  }
  ## Probability of finding a matrix with a larger eigenvalue at random
  ProbabilityLargerEigenvalue <- sum(EigenRandomizations >= EigenA) / HowMany
  
  return(list(Success=1,
              A=A, Eigen=EigenA,
              EigenRand=EigenRandomizations,
              Probability=ProbabilityLargerEigenvalue,
              Test="Test 3"))
}

#############################################
# TEST FOR  NESTEDNESS 4
#############################################
## Try matrices which have the same number
## of links, plants and animals of the original
## and maintain binary structure while
## shuffling the position of non-zero coefficients
## Give probability of 1 for binary matrices
TestNestednessEigen4 <- function(A, HowMany){
  ## Check whether the empirical graph is connected
  Connected <- IsBipartiteGraphConnected(A)
  if (Connected==0){
    print("Warning: graph is not connected.")
    print("Run ExtractGiantComponent() to obtain largest connected graph.")
    return(0)
  }
  ## Dominant eigenvalue of the original matrix
  EigenA <- DominantEigenFromIncidence(A)
  ## Vector to store eigen for randomizations
  EigenRandomizations <- rep(-1.0, HowMany)
  ## How many we tried so far
  Tried <- 0
  NumP <- dim(A)[1]
  NumA <- dim(A)[2]
  for (Tried in 1:HowMany){
    ## Build a matrix by shuffling the coefficients but maintaining binary structure
    B <- A
    B[B > 0] <- sample(B[B > 0])
    ## Compute its eigenvalue
    EigenRandomizations[Tried] <- DominantEigenFromIncidence(B)
  }
  ## Probability of finding a matrix with a larger eigenvalue at random
  ProbabilityLargerEigenvalue <- sum(EigenRandomizations >= EigenA) / HowMany
  
  return(list(Success=1,
              A=A, Eigen=EigenA,
              EigenRand=EigenRandomizations,
              Probability=ProbabilityLargerEigenvalue,
              Test="Test 4"))
}

