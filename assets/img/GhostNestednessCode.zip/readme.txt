``The ghost of nestedness in ecological networks''
by Phillip P.A. Staniczenko, Jason C. Kopp and Stefano Allesina
Nature Communications 4:1391 doi: 10.1038/ncomms2422 (2013)


FILES
SpectralNestedness.py  Python code for running nestedness tests
SpectralNestedness.c  C code optionally called by python code for running nestedness tests
SpectralNestedness.R  R code for running nestedness tests
GetPreferences.R  R code for getting preference matrix from a matrix of counts
Test-5-4.txt  Quantitative test matrix


INSTRUCTIONS

SpectralNestedness.py  (and SpectralNestedness.c)

================
Input:
================
In a terminal window, and in the directory containing the python script and incidence matrix file, type:

python SpectralNestedness.py MatrixFile.txt BinOrQuant Test Randomizations NumberOfTries [OPTIONAL] IN_C

e.g., 
> python SpectralNestedness.py Test-5-4.txt 0 2 10000 100000

- MatrixFile.txt  a space-separated incidence (bipartite) matrix

- BinOrQuant  set to 0 to convert matrix to binary and run tests
              set to 10 to use the original quantitative version

- Test set to 1 for random matrices with same |P|, |A| and |E| but allowing unconnected graphs
       set to 2 for random matrices with same |P|, |A| and |E| but only connected graphs are allowed
       set to 3 for random matrices with same |P|, |A| and |E| and degree distribution
       set to 4 for random matrices with same binary structure but nonzero coefficients are shuffled

- Randomizations  the number of random matrices to test against for determining the p-value for nestedness

- NumberOfTries for Test 1, not required
                for Test 2, the total number of random matrices to build (disconnected graphs are discarded)
                for Test 3, the number of trial swaps to attempt per randomization
                for Test 4, not required

- IN_C (Optional) if the last argument is "IN_C", the program tries to compile a C program to 
                  perform the computation and runs it. It requires gcc (the GNU C Compiler) and
                  the library gsl (GNU Scientific Library). Running the tests in C should lead to a much faster run. 

==========
Output: 
==========
p-value for nestedness. p < 0.05 means graph is significantly nested
                        p > 0.95 mean graph is significantly anti-nested



SpectralNestedness.R

If you source("SpectralNestedness.R")

Tests for nestedness for a binary or quantitative incidence (bipartite) matrix A, tests return:
i) Success  1 if test completes successfully, 0 otherwise
ii) Eigen  dominant eigenvalue of the empirical provided matrix
iii) EigenRand  vector of dominant eigenvalues of randomized matrices
iv) Probability  p-value for nestedness, p < 0.05 means graph is significantly nested
                                         p > 0.95 mean graph is significantly anti-nested
v) Test  which test was run           


TestNestednessEigen1(A, HowMany)
where HowMany is the number of ER random graphs to test against
(shuffle matrix coefficients)

TestNestednessEigen2(A, HowMany, HowManyToTry)
where HowMany is the number of connected ER random graphs to test against
(shuffle matrix coefficients and ensure graph is connected)
and HowManyToTry is the total number of randomisations to try to find connected graphs

TestNestednessEigen3(A, HowMany, HowManyToTry)
where HowMany is the number of graphs with the same degree distribution as A to test against
and HowManyToTry is the number of trial swaps to attempt for each test graph

TestNestednessEigen4(A, HowMany)
where HowMany is the number of randomisations to test against
(shuffle non-zero matrix coefficients, binary structure is maintained)

e.g., 
source("SpectralNestedness.R")
A <- as.matrix(read.table("Test-5-4.txt"))
MyOutput <- TestNestednessEigen2(A, 10000, 100000)
MyOutput$Probability


Other functions

Find perfectly nested binary matrix with minimum spectral radius:
BuildNestedWithMinEigen(NumP=7, NumA=6, Links=23)

Extract giant connected component from incidence matrix A:
ExtractGiantComponent(A)


GetPreferences.R

If you source("GetPreferences.R")

Input: a quantitative incidence (bipartite) matrix of counts
Output: a quantitative incidence (bipartite) matrix of preferences (1 represents mass action)

