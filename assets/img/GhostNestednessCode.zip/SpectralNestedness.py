#!/usr/bin/python

"""Spectral graph tests for nestedness.

Designed to work on python v2.7
Requires scipy, numpy and networkx modules to be installed.

Please cite:
``The ghost of nestedness in ecological networks''
by Phillip P.A. Staniczenko, Jason C. Kopp and Stefano Allesina
Nature Communications 4:1391 doi: 10.1038/ncomms2422 (2013)

INSTRUCTIONS
================
Input:
================
In a terminal window, and in the directory containing the python script and incidence matrix file, type:

python SpectralNestedness.py MatrixFile.txt BinOrQuant Test Randomizations NumberOfTries [OPTIONAL] IN_C

e.g., 
> python SpectralNestedness.py Test-5-4.txt 0 2 10000 100000

- MatrixFile.txt  a space-separated incidence (bipartite) matrix

- BinOrQuant  set to 0 to convert matrix to binary and run tests
              set to 10 to use the original quantitative version

- Test set to 1 for random matrices with same |P|, |A| and |E| but allowing unconnected graphs
       set to 2 for random matrices with same |P|, |A| and |E| but only connected graphs are allowed
       set to 3 for random matrices with same |P|, |A| and |E| and degree distribution
       set to 4 for random matrices with same binary structure but nonzero coefficients are shuffled

- Randomizations  the number of random matrices to test against for determining the p-value for nestedness

- NumberOfTries for Test 1, not required
                for Test 2, the total number of random matrices to build (disconnected graphs are discarded)
                for Test 3, the number of trial swaps to attempt per randomization
                for Test 4, not required

- IN_C (Optional) if the last argument is "IN_C", the program tries to compile a C program to 
                  perform the computation and runs it. It requires gcc (the GNU C Compiler) and
                  the library gsl (GNU Scientific Library). Running the tests in C should lead to a much faster run. 

==========
Output: 
==========
p-value for nestedness. p < 0.05 means graph is significantly nested
                        p > 0.95 mean graph is significantly anti-nested
"""

__author__ = 'Phillip P.A. Staniczenko (phillip.staniczenko@gmail.com) and J.C. Kopp and S. Allesina'
__version__ = '1.0'

# on UK mac, press alt+3 to get #-symbol

# imports
import sys
import scipy
import numpy
import copy
import scipy.linalg
import random
import networkx
import os.path
import os
from random import randint

# functions
def DominantEigenFromIncidence(A):
    """Return dominant eigenvalue of incidence matrix A"""
    NumP = A.shape[0]
    NumA = A.shape[1]
    S = NumP + NumA
    Adj = scipy.zeros((S, S))
    Adj = scipy.array(Adj)
    Adj[0:NumP, NumP:S] = A
    Adj = Adj + scipy.transpose(Adj)
    DominantEigenvalue = max(abs(scipy.linalg.eigvals(Adj)))
    return DominantEigenvalue
    
def isConnected(A):
    """Return 1 if graph is connected"""
    NumP = A.shape[0]
    NumA = A.shape[1]
    G = networkx.Graph()
    G.add_nodes_from(range(NumP + NumA))
    for i in range(NumP):
        for j in range(NumA):
            if A[i, j] > 0.0:
                G.add_edge(i, NumP + j)
                G.add_edge(NumP + j, i)
    check = networkx.is_connected(G)
    return check

def TestNestednessEigen1(A, HowMany):
    """Return probability of finding random matrices using Test 1"""    
    ## Try matrices which have the same number
    ## of links, plants and animals of the original
    ## but do not check for connectedness
    Connected = isConnected(A)
    if Connected == 0:
        print("Warning: graph is not connected. Please input a connected graph.")
        return 0
    EigenA = DominantEigenFromIncidence(A)
    EigenRandomizations = -1.0 * scipy.ones(HowMany)
    Tried = 0
    NumP = A.shape[0]
    NumA = A.shape[1]
    for Tried in range(HowMany):
        B = copy.deepcopy(A)
        B = scipy.reshape(B, (NumP * NumA, 1))
        B = scipy.array(random.sample(B, NumP * NumA))  ## new matrix by permuting coefficients
        B = scipy.reshape(B, (NumP, NumA))
        EigenRandomizations[Tried] = DominantEigenFromIncidence(B)
    ProbabilityLargerEigenvalue = sum(EigenRandomizations >= EigenA) / (1.0 * HowMany)
    return ProbabilityLargerEigenvalue
    
def TestNestednessEigen2(A, HowMany, HowManyToTry = -1):
    """Return probability of finding random matrices using Test 2"""    
    ## Try matrices which have the same number
    ## of links, plants and animals of the original
    ## and are connected
    Connected = isConnected(A)
    if Connected == 0:
        print("Warning: graph is not connected. Please input a connected graph.")
        return 0
    if HowManyToTry == -1:
        HowManyToTry = HowMany * 10
    EigenA = DominantEigenFromIncidence(A)
    EigenRandomizations = -1.0 * scipy.ones(HowMany)
    Tried = -1
    Found = -1
    NumP = A.shape[0]
    NumA = A.shape[1]
    while (Tried < (HowManyToTry - 1)) & (Found < (HowMany - 1)):
        Tried = Tried + 1
        Connected = 0
        B = copy.deepcopy(A)
        B = scipy.reshape(B, (NumP * NumA, 1))
        B = scipy.array(random.sample(B, NumP * NumA))  ## new matrix by permuting coefficients
        B = scipy.reshape(B, (NumP, NumA))
        Connected = isConnected(B)
        if Connected:
            Found = Found + 1
            EigenRandomizations[Found] = DominantEigenFromIncidence(B)
    ProbabilityLargerEigenvalue = sum(EigenRandomizations[EigenRandomizations > -1.0] >= EigenA) / (1.0 * (Found + 1))
    if Found < (HowMany - 1):
        print("Warning: I could not find enough connected graphs!")
    return ProbabilityLargerEigenvalue
    
def TestNestednessEigen3(A, HowMany, HowManyToTry = -1):
    """Return probability of finding random matrices using Test 3"""    
    ## Try matrices which have the same number
    ## of links, plants and animals of the original
    ## and maintain the degree distribution
    ## Uses ``Trial swap'' algorithm: Mikl\'os, I. & Podani, J. 
    ##   Randomization of presence-absence matrices: Comments and new algorithms.
    ##   Ecology 85, 86-92 (2004).
    Connected = isConnected(A)
    if Connected == 0:
        print("Warning: graph is not connected. Please input a connected graph.")
        return 0
    if HowManyToTry == -1:
        HowManyToTry = HowMany * 10
    EigenA = DominantEigenFromIncidence(A)
    EigenRandomizations = -1.0 * scipy.ones(HowMany)
    Tried = 0
    NumP = A.shape[0]
    NumA = A.shape[1]
    for Tried in range(HowMany):
        B = copy.deepcopy(A)
        count1 = 0
        while (count1 < HowManyToTry):
            count1 = count1 + 1
            ## pick two rows and two columns
            row1 = random.sample(range(NumP), 1)
            row2 = random.sample(range(NumP), 1)
            col1 = random.sample(range(NumA), 1)
            col2 = random.sample(range(NumA), 1)
            ## check swappable
            if (B[row1, col1] == 0.0) & (B[row1, col2] > 0.0) & (B[row2, col1] > 0.0) & (B[row2, col2] == 0.0):
                ## swap
    	        B[row1, col1] = B[row1, col2]
    	        B[row1, col2] = 0.0
    	        B[row2, col2] = B[row2, col1]
    	        B[row2, col1] = 0.0
    	    else:
    	        if (B[row1, col1] > 0.0) & (B[row1, col2] == 0.0) & (B[row2, col1] == 0.0) & (B[row2, col2] > 0.0):
    	            ## swap
    	            B[row1, col2] = B[row1, col1]
    	            B[row1, col1] = 0.0
    	            B[row2, col1] = B[row2, col2]
    	            B[row2, col2] = 0.0
        EigenRandomizations[Tried] = DominantEigenFromIncidence(B)
    ProbabilityLargerEigenvalue = sum(EigenRandomizations >= EigenA) / (1.0 * HowMany)
    return ProbabilityLargerEigenvalue
    
def TestNestednessEigen4(A, HowMany):
    """Return probability of finding random matrices using Test 4"""    
    ## Try matrices which have the same number
    ## of links, plants and animals of the original
    ## and maintain binary structure while
    ## shuffling the position of non-zero coefficients
    ## Give probability of 1 for binary matrices
    Connected = isConnected(A)
    if Connected == 0:
        print("Warning: graph is not connected. Please input a connected graph.")
        return 0
    EigenA = DominantEigenFromIncidence(A)
    EigenRandomizations = -1.0 * scipy.ones(HowMany)
    Tried = 0
    NumP = A.shape[0]
    NumA = A.shape[1]
    NonZeroCoefficients = A[A > 0]
    for Tried in range(HowMany):
        B = copy.deepcopy(A)
        random.shuffle(NonZeroCoefficients)
        B = scipy.reshape(B, (NumP * NumA, 1))
        count1 = -1
        for i in range(len(B)):
            if B[i] > 0:
                count1 = count1 + 1
                B[i] = NonZeroCoefficients[count1]
        B = scipy.reshape(B, (NumP, NumA))
        EigenRandomizations[Tried] = DominantEigenFromIncidence(B)
    ProbabilityLargerEigenvalue = sum(EigenRandomizations >= EigenA) / (1.0 * HowMany)
    return ProbabilityLargerEigenvalue

def maininc(argv):
    # User inputs
    filename = sys.argv[1]
    quantitative = sys.argv[2]
    test = sys.argv[3]
    HowMany = sys.argv[4]
    if len(sys.argv) > 5: 
        HowManyToTry = sys.argv[5]
    else:
        HowManyToTry = -1
    
    A = scipy.genfromtxt(filename)
    NumRows = A.shape[0]
    NumCols = A.shape[1]
    # check whether the compiled code exists
    if not os.path.isfile("./SpectralNestedness"):
        # compile the code:
        print "Compiling the code"
        os.system("gcc SpectralNestedness.c -o SpectralNestedness -lgsl -lgslcblas -O3")
    if not os.path.isfile("./SpectralNestedness"):
        print "Cannot complie the code. Please try to do it by hand (see the first lines in SpectralNestedness.c"
    else:
        # draw a random number
        rndseed = randint(1,10000)
        # call the C program
        mylaunch = "./SpectralNestedness " +  str(NumRows) + " " + str(NumCols) + " " + filename + " " + str(quantitative) + " " + str(rndseed) + " " + str(test) + " " + str(HowMany) + " " + str(HowManyToTry)
        print "Launching\n", mylaunch
        os.system(mylaunch)
    return 0

def main(argv):
    # User inputs
    filename = sys.argv[1]
    quantitative = sys.argv[2]
    test = sys.argv[3]
    HowMany = sys.argv[4]
    if len(sys.argv) > 5: 
        HowManyToTry = sys.argv[5]
    else:
        HowManyToTry = -1
    
    A = scipy.genfromtxt(filename)
    if quantitative == "0":
        A[A > 0.0] = 1  ## convert to binary matrix
    
    if test == "1":
        TestResult = TestNestednessEigen1(A, int(HowMany))
        print "p-value for nestedness (p < 0.05: nested; p > 0.95: anti-nested)"
        print TestResult
    if test == "2":
        TestResult = TestNestednessEigen2(A, int(HowMany), int(HowManyToTry))
        print "p-value for nestedness (p < 0.05: nested; p > 0.95: anti-nested)"
        print TestResult
    if test == "3":
        TestResult = TestNestednessEigen3(A, int(HowMany), int(HowManyToTry))
        print "p-value for nestedness (p < 0.05: nested; p > 0.95: anti-nested)"
        print TestResult
    if test == "4":
        TestResult = TestNestednessEigen4(A, int(HowMany))
        print "p-value for nestedness (p < 0.05: nested; p > 0.95: anti-nested)"
        print TestResult
    
    return 0

if (__name__ == "__main__"):
    status = -1
    # If the last parameter is IN_C
    if sys.argv[-1] == "IN_C":
        status = maininc(sys.argv[0:-1])
    else:
        status = main(sys.argv)
    sys.exit(status)

