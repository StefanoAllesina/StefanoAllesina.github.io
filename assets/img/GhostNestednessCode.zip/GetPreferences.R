library(kinship)  # for LDL decomposition
library(corpcor)  # for pseudoinverse

#############################################
# GET PREFERENCES FROM INCIDENCE MATRIX OF INTERACTION COUNTS
#############################################
## Please cite:
## ``The ghost of nestedness in ecological networks''
## by Phillip P.A. Staniczenko, Jason C. Kopp and Stefano Allesina
## Nature Communications 4:1391 doi: 10.1038/ncomms2422 (2013)
##
## Input: a quantitative incidence (bipartite) matrix of counts
## Output: a quantitative incidence (bipartite) matrix of preferences (1 represents mass action)
GetPreference <- function(A){
  # get adjacency quantitative matrix
  Aquant <- mat.or.vec(nr=dim(A)[1], nc=dim(A)[1])
  Aquant <- cbind(Aquant, A)
  Aquant2 <- t(A)
  Aquant2 <- cbind(Aquant2, mat.or.vec(nr=dim(A)[2], nc=dim(A)[2]))
  Aquant <- rbind(Aquant, Aquant2)

  # get binary matrix
  Abinary <- Aquant
  Abinary[Abinary > 0] <- 1

  # get interaction list matrix, K, and log scaled entries vector, y
  K <- mat.or.vec(nr=sum(Abinary), nc=dim(Abinary)[1])
  y <- mat.or.vec(nr=sum(Abinary), nc=1)
  counter <- 0
  for (i in 1:dim(Abinary)[1]){
  	for (j in 1:dim(Abinary)[2]){
      if (Abinary[i, j] == 1){
        counter <- counter + 1
		y[counter] <- log(Aquant[i, j])
		K[counter, i] <- 1
		K[counter, j] <- 1
	  }
	}
  }
		
  # get t(K)K
  KTK <- t(K) %*% K

  # use LDL decomposition method?
  if(FALSE){
    # LDL decomposition
	gt <- gchol(KTK)
	L <- as.matrix(gt)
	D <- diag(gt)
	D[D==0] <- 0.05
	LDLT<-L%*%diag(D)%*%t(L)	

	# get t(K)y
	KTy <- t(K) %*% y

	# solve for X
	X <- solve(LDLT, KTy)
  }

  # use pseudoinverse method
  if (TRUE){
    X <- pseudoinverse(K, 1e-8) %*% y
  }

  X <- exp(X)

  # get mass action normalisation
  norm <- X %*% t(X)

  # perfrom normalisation
  Anorm <- Aquant / norm
	
  # select out bipartite component
  pref <- Anorm[1:dim(A)[1], (dim(Anorm)[2] - dim(A)[2] + 1):dim(Anorm)[2]]
  pref <- round(pref, digits=3)

  return(pref)
}