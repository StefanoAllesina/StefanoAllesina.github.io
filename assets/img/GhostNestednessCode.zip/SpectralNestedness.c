////////////////////////////////////////////////////////////////
// Performs the test on nestedness
// as specified by Staniczenko et al. Nature Communications 2013
// Code written by Stefano Allesina (sallesina@uchicago.edu) and
// Phillip Staniczenko (pstaniczenko@uchicago.edu)
////////////////////////////////////////////////////////////////
// REQUIREMENTS:
// gcc, the GNU C Compiler (http://gcc.gnu.org/)
// gsl, the GNU Scientific Library
//      (http://www.gnu.org/software/gsl/)
////////////////////////////////////////////////////////////////
// TO COMPILE:
// gcc SpectralNestedness.c -o SpectralNestedness -lgsl -lgslcblas -O3
////////////////////////////////////////////////////////////////
// TO LAUNCH:
// ./SpectralNestedness 5 4 Test-5-4.txt 0 123 3 1000 5000
// 5 -> Number of Rows
// 4 -> Number of Columns
// Test-5-4.txt -> space-separated incidence matrix (either binary or
//                 quantitative)
// 0 -> use as binary matrix (1 for quantitative)
// 123 -> seed for random number generator
// 3 -> test to perform (possible choices: 1, 2, 3, and 4).
// 1000 -> number of replicates for p-value computation
// 5000 -> number of swaps to be used in test 3
////////////////////////////////////////////////////////////////
// OUTPUT:
// the p-value for the test and matrix
////////////////////////////////////////////////////////////////

// Header files
#include <stdio.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_randist.h>
// Tolerance for the difference in eigenvalues
#define TOLERANCE 1e-10
// For more detailed information on the run, set to 1
int DEBUG=0;

// FUNCTIONS
// Build Adjacency matrix from Incidence matrix
int BuildAdj(gsl_matrix * Incidence, gsl_matrix * Adjacency){
	int i, j, Rows, Cols;
	Rows = Incidence->size1;
	Cols = Incidence->size2;
	gsl_matrix_set_zero(Adjacency);
	for (i = 0; i < Rows; i++){
		for (j = 0; j < Cols; j++){
			gsl_matrix_set(Adjacency, i, j + Rows, gsl_matrix_get(Incidence, i, j));
			gsl_matrix_set(Adjacency, j + Rows, i, gsl_matrix_get(Incidence, i, j));
		}
	}
	return 0;
}

// DFS module for Nestedness. Compute components and whether a graph is connected.
int DFS_Visit(gsl_matrix * Adjacency, int NodeToVisit, int Color, gsl_vector * Visited){
	gsl_vector_set(Visited, NodeToVisit, Color);
	int i, S;
	S = Adjacency->size1;
	for (i = 0; i < S; i++){
		if (gsl_matrix_get(Adjacency, NodeToVisit, i) > 0.0){
			if (gsl_vector_get(Visited, i) < 0.0){
				DFS_Visit(Adjacency, i, Color, Visited);
			}
		}
	}
	return 0;
}

// Perform Depth First Search
int DFS(gsl_matrix * Adjacency, gsl_vector * Visited){
	gsl_vector_set_all(Visited, -1.0);
	// each color is a component
	int MyCol, i, S;
	S = Adjacency->size1;
	MyCol = 0;
	for (i = 0; i < S; i++){
		if (gsl_vector_get(Visited, i) < 0.0){
			DFS_Visit(Adjacency, i, MyCol, Visited);
			MyCol++; 
		}
	}
	return 0;
}

// Return 0 if the graph is connected
int IsConnected(gsl_matrix * Adjacency){
	int S; 
	int NumDiscComponents;
	S = Adjacency->size1;
	gsl_vector * AlreadyVisited = gsl_vector_calloc(S);
	DFS(Adjacency, AlreadyVisited);
	NumDiscComponents = ((int) gsl_vector_max(AlreadyVisited));
	if (NumDiscComponents > 0){
		gsl_vector_free(AlreadyVisited);
		return (NumDiscComponents);
	}
	gsl_vector_free(AlreadyVisited);    
	return 0;
}

// Return largest eigenvalue from adjacency matrix
double EigenValueFromAdjacency(gsl_matrix * Adjacency){
	int S = Adjacency->size1;
	gsl_vector * eval = gsl_vector_calloc(S); // store eigenvalues
	gsl_eigen_symm_workspace * w = gsl_eigen_symm_alloc(S); 
	gsl_eigen_symm(Adjacency, eval, w);
	double Eig1 = gsl_vector_max(eval);
	gsl_vector_free(eval);
	gsl_eigen_symm_free(w);
	return (Eig1);
}

// Generate matrix with the same size and fill
int GenerateMatrixNoConstraints(gsl_matrix * Incidence, gsl_matrix * Generated, const gsl_rng * r){
	gsl_matrix_memcpy(Generated, Incidence);
	gsl_ran_shuffle (r, Generated->data, (size_t) ((Generated->size1) * (Generated->size2)), (size_t) sizeof(double));
	return 1;
}

// Generate matrix but accept only connected
int GenerateMatrixConnected(gsl_matrix * Incidence, gsl_matrix * Generated, const gsl_rng * r){
	gsl_matrix_memcpy(Generated, Incidence);
	int FoundConnected = 1000;
	int S = (Generated->size1) + (Generated->size2);
	gsl_matrix * Adj = gsl_matrix_calloc(S,S);
	int k = 0;
	while (FoundConnected != 0){
		k++;
		gsl_ran_shuffle(r,Generated->data,(size_t) ((Generated->size1)*(Generated->size2)), (size_t) sizeof(double));
		BuildAdj(Generated, Adj);
		FoundConnected = IsConnected(Adj); // returns 0 when the graph
		// is connected
	}
	gsl_matrix_free(Adj);
	return 1;
}

// Swap using checkerboards
int SwapMatrix(gsl_matrix * Generated, const gsl_rng *r,
			   int MaxTrySwap){
	int NR = Generated->size1;
	int NC = Generated->size2;
	int count1;
	int row1, row2, col1, col2;
	count1 = 0;
	while((count1 < MaxTrySwap)){
		count1++;
		// pick two rows and two cols
		row1 = gsl_rng_uniform_int(r, NR);
		row2 = gsl_rng_uniform_int(r, NR);
		col1 = gsl_rng_uniform_int(r, NC);
		col2 = gsl_rng_uniform_int(r, NC);
		// check the configuration
		if ((gsl_matrix_get(Generated,row1,col1) == 0.0)
			&&
			(gsl_matrix_get(Generated,row1,col2) > 0.0)
			&& 
			(gsl_matrix_get(Generated,row2,col1) > 0.0)
			&& 
			(gsl_matrix_get(Generated,row2,col2) == 0.0)){
			// SWAP!
			gsl_matrix_set(Generated, row1, col1, gsl_matrix_get(Generated, row1, col2));
			gsl_matrix_set(Generated, row1, col2, 0.0);
			gsl_matrix_set(Generated, row2, col2, gsl_matrix_get(Generated, row2, col1));
			gsl_matrix_set(Generated, row2, col1, 0.0);
		}
		else{
			if ((gsl_matrix_get(Generated, row1, col1) > 0.0)
				&&
				(gsl_matrix_get(Generated, row1, col2) == 0.0)
				&& 
				(gsl_matrix_get(Generated, row2, col1) == 0.0)
				&& 
				(gsl_matrix_get(Generated, row2, col2) > 0.0)){
				// SWAP!
				gsl_matrix_set(Generated, row1, col2, gsl_matrix_get(Generated, row1, col1));
				gsl_matrix_set(Generated, row1, col1, 0.0);
				gsl_matrix_set(Generated, row2, col1, gsl_matrix_get(Generated, row2, col2));
				gsl_matrix_set(Generated, row2, col2, 0.0);
			}
		}
	}
	return 0;
}

// generate a quantitative matrix shuffling only the coefficients that
// are nonzero
int GenerateMatrixQuantitative(gsl_matrix * Incidence, gsl_matrix * Generated, const gsl_rng * r){
	int NR,NC;
	NR = Incidence->size1;
	NC = Incidence->size2;
	gsl_vector * Tmp = gsl_vector_calloc(NR * NC);
	int i, j, k;
	double X;
	k=0;
	// extract all non zero values
	for (i = 0; i < NR; i++){
		for (j = 0; j < NC; j++){
			X = gsl_matrix_get(Incidence, i, j);
			if (X > 0.0){
				gsl_vector_set(Tmp, k, X);
				k++;
			}
		}
	}
	// Now shuffle
	gsl_ran_shuffle (r, Tmp->data, (size_t) (k), (size_t) sizeof(double));
	// and fill the matrix
	gsl_matrix_set_zero(Generated);
	k = 0;
	for (i = 0; i < NR; i++){
		for (j = 0; j < NC; j++){
			if (gsl_matrix_get(Incidence, i, j) > 0.0){
				gsl_matrix_set(Generated, i, j, gsl_vector_get(Tmp, k));
				k++;
			}
		}
	}
	gsl_vector_free(Tmp);
	return 1;
}

// generate a matrix keeping the degree distribution
int GenerateMatrixConnectedDegreeDistribution(gsl_matrix * Incidence, gsl_matrix * Generated, const gsl_rng * r, int MaxTrySwap){
	int FoundConnected = 1000;
	int S = (Generated->size1) + (Generated->size2);
	gsl_matrix * Adj = gsl_matrix_calloc(S, S);
	int k = 0;
	while (FoundConnected != 0){
		k++;
		gsl_matrix_memcpy(Generated, Incidence);
		SwapMatrix(Generated, r, MaxTrySwap);
		BuildAdj(Generated, Adj);
		FoundConnected = IsConnected(Adj);
	}
	gsl_matrix_free(Adj);
	// Now make sure to shuffle the coefficients
	gsl_matrix * Generated2 = gsl_matrix_calloc(Generated->size1, Generated->size2);
	// Shuffle
	GenerateMatrixQuantitative(Generated, Generated2, r);
	// copy the matrix
	gsl_matrix_memcpy(Generated, Generated2);
	gsl_matrix_free(Generated2); 
	return 1;
}

int PrintMatrix(gsl_matrix * A){
	int NR=A->size1;
	int NC=A->size2;
	int i,j;
	for (i=0;i<NR;i++){
		for (j=0;j<NC;j++){
			if (gsl_matrix_get(A,i,j)==0.0){
				fprintf(stderr, "0    ");
			}
			else{
				fprintf(stderr, "%1.2f ",gsl_matrix_get(A,i,j));
			}
		}
		fprintf(stderr, "\n");
	}
	fprintf(stderr, "\n");
	return 0;
}

int main(int argc, char *argv[]){
	// input parameters
	int NumP = atoi(argv[1]); // number of rows (plants)
	int NumA = atoi(argv[2]); // number of cols (animals)
	char * FileName = argv[3]; // file storing incidence matrix
	int BinaryQuant = atoi(argv[4]); // binary (0) or quantitative (>0)
	int seed = atoi(argv[5]); // random seed
	int TestNum = atoi(argv[6]); // Test number (1,2,3,4)
	int Replicates = atoi(argv[7]); // number of randomizations
	int HowManySwaps = 1000;
	if (argc>8){
		// optional argument for test 3
		HowManySwaps = atoi(argv[8]);
	}
	gsl_matrix * Incidence = gsl_matrix_calloc(NumP, NumA);
	gsl_matrix * Generated = gsl_matrix_calloc(NumP, NumA);
	int S = (NumP + NumA);
	gsl_matrix * Adj = gsl_matrix_calloc(S, S);
	// read incidence matrix
	FILE * F;
	F = fopen(FileName,"rb");
	gsl_matrix_fscanf(F, Incidence);
	fclose(F);
	if (DEBUG==1){
		fprintf(stderr,"Original Incidence\n");
		PrintMatrix(Incidence);
	}
	
	// Transform to binary
	int i, j;
	if (BinaryQuant == 0){
		for (i = 0; i < NumP; i++){
			for (j = 0; j < NumA; j++){
				if (gsl_matrix_get(Incidence, i, j) > 0.0){
					gsl_matrix_set(Incidence, i, j, 1.0);
				}
			}
		}
	}
	if (DEBUG == 1){
		fprintf(stderr,"Transformed Incidence\n");
		PrintMatrix(Incidence);
	}
	// set up random number generator
	const gsl_rng_type * T;
	gsl_rng * r;
	gsl_rng_env_setup();
	T = gsl_rng_default;
	r = gsl_rng_alloc(T);
	gsl_rng_set (r, seed);
	// To store eigenvalues
	double OrigEig = 0.0;
	BuildAdj(Incidence, Adj);
	OrigEig = EigenValueFromAdjacency(Adj);
	BuildAdj(Incidence, Adj);
	if (DEBUG == 1){
		PrintMatrix(Adj);
		fprintf(stderr, "Original Adj: %f\n", OrigEig);
	}

	// Check whether the original matrix is connected
	int IsOriginalConnected = IsConnected(Adj);
	if (IsOriginalConnected != 0){
		fprintf(stderr, "Warning: graph is not connected. Please input a connected graph.\n");
	}
	else{
		double CurEig = 0.0;
		double PValue = 0.0;
		int OutputStep = (int) 25 * Replicates / 100;
		for (i = 0; i < Replicates; i++){
			if ((i % OutputStep) == 0) fprintf(stderr,"%d %% Complete\n", 25*(int) (i / OutputStep));
			if (TestNum == 1){
				GenerateMatrixNoConstraints(Incidence, Generated, r);
			}
			if (TestNum == 2){
				GenerateMatrixConnected(Incidence, Generated, r);
			}
			if (TestNum == 3){
				GenerateMatrixConnectedDegreeDistribution(Incidence, Generated, r, HowManySwaps);
			}
			if (TestNum == 4){
				GenerateMatrixQuantitative(Incidence, Generated, r);
			}
			BuildAdj(Generated, Adj);
			CurEig = EigenValueFromAdjacency(Adj);
			if (DEBUG == 1){
				fprintf(stderr, "Replicate Adj: %f\n", OrigEig);
			}
			if ((OrigEig - CurEig) <= TOLERANCE){
				PValue++;
			}
		}
		PValue /= (double) Replicates;
		fprintf(stderr, "p-value for nestedness (p < 0.05: nested; p > 0.95: anti-nested)\n");
		fprintf(stdout, "%f\n", PValue);
	}
	// free memory
	gsl_matrix_free(Incidence);
	gsl_matrix_free(Generated);
	gsl_matrix_free(Adj);
	gsl_rng_free (r);
	return 0;
}
